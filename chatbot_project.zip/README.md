# 🤖 Simple Chatbot (Python + Flask)

A beginner-friendly chatbot project built using **Flask**.  
Users can chat with the bot through a simple web interface.

## 🚀 Features
- Simple web-based chat interface  
- Auto replies to common queries  
- Built using Python Flask  

## 🛠️ Tech Stack
- Python (Flask)
- HTML, CSS, JavaScript

## ⚙️ Setup Instructions

```bash
git clone https://github.com/YOUR-USERNAME/chatbot_project.git
cd chatbot_project
pip install flask
python app.py
```

Then open: 👉 [http://127.0.0.1:5000](http://127.0.0.1:5000)
