from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

responses = {
    "hi": ["Hello!", "Hey there!", "Hi! How can I help you?"],
    "how are you": ["I'm just a bot, but I'm doing great! 😄", "I'm good! How about you?"],
    "bye": ["Goodbye!", "See you later!", "Take care!"],
    "name": ["I'm your friendly chatbot 🤖", "You can call me ChatBot!"]
}

def get_response(user_input):
    user_input = user_input.lower()
    for key in responses:
        if key in user_input:
            return random.choice(responses[key])
    return "I'm not sure I understand that. Can you rephrase?"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    bot_reply = get_response(user_message)
    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
