# 🗂️ Task Manager (Python + Flask)

A simple Task Manager web app built with **Flask** and **SQLite**.

## 🚀 Features
- Add, Edit, and Delete Tasks  
- Mark tasks as Pending or Completed  
- Simple responsive interface  

## 🛠️ Tech Stack
- Python (Flask)
- SQLite
- HTML, CSS

## ⚙️ Setup Instructions

```bash
git clone https://github.com/YOUR-USERNAME/task_manager.git
cd task_manager
pip install flask
python app.py
```

Then open: 👉 [http://127.0.0.1:5000](http://127.0.0.1:5000)
